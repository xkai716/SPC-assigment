#include <cctype>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

const string COMPANY_NAME = "J&J AutoCare Workshop";
const int WORKING_DAYS = 5, TIME_SLOT_COUNT = 4, MECHANIC_COUNT = 3;
const int MAX_APPOINTMENTS_PER_SLOT = 3;

const string DATES[WORKING_DAYS] = {
    "18/08/2026 (Monday)", "19/08/2026 (Tuesday)",
    "20/08/2026 (Wednesday)", "21/08/2026 (Thursday)",
    "22/08/2026 (Friday)"};

const string SLOTS[TIME_SLOT_COUNT] = {
    "09:00 AM - 10:30 AM", "11:00 AM - 12:30 PM",
    "02:00 PM - 03:30 PM", "04:00 PM - 05:30 PM"};

const string MECHANICS[MECHANIC_COUNT] = {
    "Ali Rahman", "Brandon Lee", "Chen Wei Ming"};

struct Customer
{
    string id, name, phone, plate, brand, model;
};

struct Booking
{
    string id, customerId, customerName, plate, service, status;
    double price;
};

struct Appointment
{
    string id, bookingId, customerName, plate, service, mechanic, status;
    int day, slot;
};

struct Invoice
{
    string id, customerId, customerName, paymentMethod, paymentStatus;
    double total;
};

void clearScreen()
{
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

void line(int size = 72)
{
    for (int i = 0; i < size; i++)
        cout << '-';
    cout << '\n';
}

void pauseScreen()
{
    string input;
    cout << "\nPress Enter to continue...";
    getline(cin, input);
}

int numberInput(const string &prompt, int minimum, int maximum)
{
    string input;
    int value;

    while (true)
    {
        cout << prompt;
        getline(cin, input);

        stringstream parser(input);

        if (!(parser >> value) || !(parser >> ws).eof() ||
            value < minimum || value > maximum)
        {
            cout << "Invalid input. Please enter a number from "
                 << minimum << " to " << maximum << ".\n";
        }
        else
        {
            return value;
        }
    }
}

double moneyInput(const string &prompt)
{
    string input;
    double value;

    while (true)
    {
        cout << prompt;
        getline(cin, input);

        stringstream parser(input);

        if (!(parser >> value) || !(parser >> ws).eof() || value < 0)
        {
            cout << "Invalid amount. Please enter a positive number.\n";
        }
        else
        {
            return value;
        }
    }
}

string upperCase(string value)
{
    for (int i = 0; i < static_cast<int>(value.size()); i++)
    {
        value[i] = static_cast<char>(
            toupper(static_cast<unsigned char>(value[i])));
    }

    return value;
}

int findCustomer(const vector<Customer> &customers, const string &id)
{
    for (int i = 0; i < static_cast<int>(customers.size()); i++)
    {
        if (upperCase(customers[i].id) == upperCase(id))
        {
            return i;
        }
    }

    return -1;
}

int findBooking(const vector<Booking> &bookings, const string &id)
{
    for (int i = 0; i < static_cast<int>(bookings.size()); i++)
    {
        if (upperCase(bookings[i].id) == upperCase(id))
        {
            return i;
        }
    }

    return -1;
}

void syncCustomerDetails(const Customer &customer,
                         vector<Booking> &bookings,
                         vector<Appointment> &appointments)
{
    for (int i = 0; i < static_cast<int>(bookings.size()); i++)
    {
        if (bookings[i].customerId == customer.id)
        {
            bookings[i].customerName = customer.name;
            bookings[i].plate = customer.plate;

            for (int j = 0; j < static_cast<int>(appointments.size()); j++)
            {
                if (appointments[j].bookingId == bookings[i].id)
                {
                    appointments[j].customerName = customer.name;
                    appointments[j].plate = customer.plate;
                }
            }
        }
    }
}

void updateTextField(const string &label,
                     string &value,
                     bool convertToUppercase = false)
{
    string newValue;

    cout << label << " [" << value << "] (press Enter to keep): ";
    getline(cin, newValue);

    if (!newValue.empty())
    {
        value = convertToUppercase ? upperCase(newValue) : newValue;
    }
}

// MODULE 1: CUSTOMER & VEHICLE MANAGEMENT
void customerMenu(vector<Customer> &customers,
                  vector<Booking> &bookings,
                  vector<Appointment> &appointments,
                  int &nextCustomer)
{
    int choice;

    do
    {
        clearScreen();

        cout << "\n=== CUSTOMER & VEHICLE MANAGEMENT ===\n";
        cout << "1. Add Customer & Vehicle\n";
        cout << "2. View Customer List\n";
        cout << "3. Search Customer\n";
        cout << "4. Update Customer Information\n";
        cout << "0. Return to Main Menu\n";

        choice = numberInput("Enter your choice: ", 0, 4);

        if (choice == 1)
        {
            Customer customer;
            customer.id = "C" + to_string(nextCustomer++);

            cout << "Generated Customer ID: " << customer.id << '\n';

            cout << "Customer name: ";
            getline(cin, customer.name);

            cout << "Phone number: ";
            getline(cin, customer.phone);

            cout << "Car plate number (example: VAA 1234 or WXY 5678): ";
            getline(cin, customer.plate);

            customer.plate = upperCase(customer.plate);

            cout << "Car brand (example: Toyota, Honda, Perodua): ";
            getline(cin, customer.brand);

            cout << "Car model (example: Vios, City, Myvi): ";
            getline(cin, customer.model);

            if (customer.name.empty() || customer.phone.empty() ||
                customer.plate.empty())
            {
                cout << "Required details cannot be empty.\n";
                nextCustomer--;
            }
            else
            {
                customers.push_back(customer);
                cout << "Customer registered successfully.\n";
            }
        }

        else if (choice == 2)
        {
            line(100);

            cout << left
                 << setw(10) << "Cust ID"
                 << setw(22) << "Customer"
                 << setw(16) << "Phone"
                 << setw(15) << "Plate"
                 << setw(18) << "Brand"
                 << "Model\n";

            line(100);

            if (customers.empty())
            {
                cout << "No customer records.\n";
            }
            else
            {
                for (int i = 0; i < static_cast<int>(customers.size()); i++)
                {
                    cout << left
                         << setw(10) << customers[i].id
                         << setw(22) << customers[i].name
                         << setw(16) << customers[i].phone
                         << setw(15) << customers[i].plate
                         << setw(18) << customers[i].brand
                         << customers[i].model << '\n';
                }
            }
        }

        else if (choice == 3 || choice == 4)
        {
            string id;

            cout << "Enter customer ID: ";
            getline(cin, id);

            int index = findCustomer(customers, id);

            if (index == -1)
            {
                cout << "Customer not found.\n";
            }

            else if (choice == 3)
            {
                cout << customers[index].name << " | "
                     << customers[index].phone << " | "
                     << customers[index].brand << " "
                     << customers[index].model << " ("
                     << customers[index].plate << ")\n";
            }

            else
            {
                cout << "\nCURRENT CUSTOMER INFORMATION\n";
                cout << "Name: " << customers[index].name << "\n";
                cout << "Phone: " << customers[index].phone << "\n";
                cout << "Plate: " << customers[index].plate << "\n";
                cout << "Brand: " << customers[index].brand << "\n";
                cout << "Model: " << customers[index].model << "\n\n";

                cout << "1. Update Customer Name\n";
                cout << "2. Update Phone Number\n";
                cout << "3. Update Car Plate Number\n";
                cout << "4. Update Car Brand\n";
                cout << "5. Update Car Model\n";
                cout << "6. Update All Information\n";
                cout << "0. Back\n";

                int updateChoice = numberInput(
                    "Choose information to update: ", 0, 6);

                if (updateChoice == 1 || updateChoice == 6)
                {
                    updateTextField(
                        "New customer name",
                        customers[index].name);
                }

                if (updateChoice == 2 || updateChoice == 6)
                {
                    updateTextField(
                        "New phone number",
                        customers[index].phone);
                }

                if (updateChoice == 3 || updateChoice == 6)
                {
                    updateTextField(
                        "New car plate number",
                        customers[index].plate,
                        true);
                }

                if (updateChoice == 4 || updateChoice == 6)
                {
                    updateTextField(
                        "New car brand (example: Toyota, Honda, Perodua)",
                        customers[index].brand);
                }

                if (updateChoice == 5 || updateChoice == 6)
                {
                    updateTextField(
                        "New car model (example: Vios, City, Myvi)",
                        customers[index].model);
                }

                if (updateChoice != 0)
                {
                    syncCustomerDetails(
                        customers[index],
                        bookings,
                        appointments);

                    cout << "Customer information updated successfully.\n";
                }
            }
        }

        if (choice != 0)
        {
            pauseScreen();
        }

    } while (choice != 0);
}

// MODULE 2: SERVICE BOOKING MANAGEMENT
string serviceName(int choice)
{
    const string names[] = {
        "Oil Change",
        "Tyre Replacement",
        "Brake Inspection",
        "Engine Checking",
        "Battery Replacement",
        "Car Wash"};

    return names[choice - 1];
}

double servicePrice(int choice)
{
    const double prices[] = {80, 250, 60, 120, 180, 30};
    return prices[choice - 1];
}

void showServices()
{
    cout << "\nAVAILABLE SERVICES\n";
    line(48);

    cout << left
         << setw(6) << "No."
         << setw(26) << "Service"
         << "Price (RM)\n";

    line(48);

    for (int i = 1; i <= 6; i++)
    {
        cout << left
             << setw(6) << i
             << setw(26) << serviceName(i)
             << fixed << setprecision(2)
             << servicePrice(i) << '\n';
    }
}

void bookingMenu(const vector<Customer> &customers,
                 vector<Booking> &bookings,
                 int &nextBooking)
{
    int choice;

    do
    {
        clearScreen();

        cout << "\n=== SERVICE BOOKING MANAGEMENT ===\n";
        cout << "1. Register Booking\n";
        cout << "2. View Bookings\n";
        cout << "3. Search Booking\n";
        cout << "4. Update Pending Booking\n";
        cout << "5. Check Service Prices\n";
        cout << "0. Return to Main Menu\n";

        choice = numberInput("Enter your choice: ", 0, 5);

        if (choice == 1)
        {
            if (customers.empty())
            {
                cout << "Register a customer first.\n";
                pauseScreen();
                continue;
            }

            cout << "\nCUSTOMERS\n";
            line(70);

            for (int i = 0; i < static_cast<int>(customers.size()); i++)
            {
                cout << customers[i].id << " | "
                     << customers[i].name << " | "
                     << customers[i].plate << '\n';
            }

            string customerId;

            cout << "Enter customer ID (0 to back): ";
            getline(cin, customerId);

            if (customerId == "0")
            {
                continue;
            }

            int customerIndex = findCustomer(customers, customerId);

            if (customerIndex == -1)
            {
                cout << "Customer not found.\n";
                pauseScreen();
                continue;
            }

            showServices();

            int serviceChoice = numberInput("Choose service: ", 1, 6);

            Booking booking;

            booking.id = "B" + to_string(nextBooking++);
            booking.customerId = customers[customerIndex].id;
            booking.customerName = customers[customerIndex].name;
            booking.plate = customers[customerIndex].plate;
            booking.service = serviceName(serviceChoice);
            booking.status = "Pending";
            booking.price = servicePrice(serviceChoice);

            bookings.push_back(booking);

            cout << "Booking " << booking.id
                 << " created successfully.\n";
        }

        else if (choice == 2)
        {
            cout << "\nSERVICE BOOKINGS\n";
            line(104);

            cout << left
                 << setw(12) << "Booking ID"
                 << setw(12) << "Cust ID"
                 << setw(22) << "Customer"
                 << setw(15) << "Plate"
                 << setw(25) << "Service"
                 << setw(10) << "Price"
                 << "Status\n";

            line(104);

            if (bookings.empty())
            {
                cout << "No bookings.\n";
            }
            else
            {
                for (int i = 0; i < static_cast<int>(bookings.size()); i++)
                {
                    cout << left
                         << setw(12) << bookings[i].id
                         << setw(12) << bookings[i].customerId
                         << setw(22) << bookings[i].customerName
                         << setw(15) << bookings[i].plate
                         << setw(25) << bookings[i].service
                         << setw(10) << fixed << setprecision(2)
                         << bookings[i].price
                         << bookings[i].status << '\n';
                }
            }
        }

        else if (choice == 3 || choice == 4)
        {
            string id;

            cout << "Enter booking ID: ";
            getline(cin, id);

            int index = findBooking(bookings, id);

            if (index == -1)
            {
                cout << "Booking not found.\n";
            }

            else if (choice == 3)
            {
                cout << bookings[index].id << " | "
                     << bookings[index].customerName << " | "
                     << bookings[index].service << " | "
                     << bookings[index].status << '\n';
            }

            else if (bookings[index].status != "Pending")
            {
                cout << "Only a pending booking can be updated.\n";
            }

            else
            {
                showServices();

                int selected = numberInput(
                    "Choose new service: ", 1, 6);

                bookings[index].service = serviceName(selected);
                bookings[index].price = servicePrice(selected);

                cout << "Booking updated.\n";
            }
        }

        else if (choice == 5)
        {
            showServices();
        }

        if (choice != 0)
        {
            pauseScreen();
        }

    } while (choice != 0);
}

// MODULE 3: APPOINTMENT / SCHEDULE MANAGEMENT
void saveAppointments(const vector<Appointment> &appointments)
{
    ofstream file("appointments.txt");

    for (int i = 0; i < static_cast<int>(appointments.size()); i++)
    {
        const Appointment &appointment = appointments[i];

        file << appointment.id << '|'
             << appointment.bookingId << '|'
             << appointment.customerName << '|'
             << appointment.plate << '|'
             << appointment.service << '|'
             << appointment.day << '|'
             << appointment.slot << '|'
             << appointment.mechanic << '|'
             << appointment.status << '\n';
    }
}

bool mechanicFree(const vector<Appointment> &appointments,
                  int day,
                  int slot,
                  const string &mechanic)
{
    for (int i = 0; i < static_cast<int>(appointments.size()); i++)
    {
        if (appointments[i].day == day &&
            appointments[i].slot == slot &&
            appointments[i].mechanic == mechanic &&
            appointments[i].status != "Cancelled")
        {
            return false;
        }
    }

    return true;
}

void appointmentMenu(vector<Appointment> &appointments,
                     vector<Booking> &bookings,
                     int schedule[WORKING_DAYS][TIME_SLOT_COUNT],
                     int &nextAppointment)
{
    int choice;

    do
    {
        clearScreen();

        cout << "\n=== APPOINTMENT / SCHEDULE MANAGEMENT ===\n";
        cout << "1. Create Appointment\n";
        cout << "2. View Daily Schedule\n";
        cout << "3. Reschedule Appointment\n";
        cout << "4. Cancel Appointment\n";
        cout << "5. Update Appointment Status\n";
        cout << "0. Return to Main Menu\n";

        choice = numberInput("Enter your choice: ", 0, 5);

        if (choice == 1)
        {
            vector<int> pending;

            for (int i = 0; i < static_cast<int>(bookings.size()); i++)
            {
                if (bookings[i].status == "Pending")
                {
                    pending.push_back(i);
                }
            }

            if (pending.empty())
            {
                cout << "No pending service booking available.\n";
                pauseScreen();
                continue;
            }

            cout << "\nPENDING BOOKINGS\n";
            line(80);

            cout << left
                 << setw(5) << "No."
                 << setw(12) << "Booking"
                 << setw(22) << "Customer"
                 << setw(15) << "Plate"
                 << "Service\n";

            line(80);

            for (int i = 0; i < static_cast<int>(pending.size()); i++)
            {
                const Booking &booking = bookings[pending[i]];

                cout << left
                     << setw(5) << i + 1
                     << setw(12) << booking.id
                     << setw(22) << booking.customerName
                     << setw(15) << booking.plate
                     << booking.service << '\n';
            }

            int bookingChoice = numberInput(
                "Choose booking number (0 back): ",
                0,
                static_cast<int>(pending.size()));

            if (bookingChoice == 0)
            {
                continue;
            }

            int bookingIndex = pending[bookingChoice - 1];

            cout << "\n0. Back\n";

            for (int i = 0; i < WORKING_DAYS; i++)
            {
                cout << i + 1 << ". " << DATES[i] << '\n';
            }

            int dayChoice = numberInput(
                "Choose date: ", 0, WORKING_DAYS);

            if (dayChoice == 0)
            {
                continue;
            }

            int day = dayChoice - 1;

            cout << "\n0. Back\n";

            for (int i = 0; i < TIME_SLOT_COUNT; i++)
            {
                cout << i + 1 << ". " << SLOTS[i]
                     << " (" << schedule[day][i] << "/3 bays)\n";
            }

            int slotChoice = numberInput(
                "Choose time slot: ", 0, TIME_SLOT_COUNT);

            if (slotChoice == 0)
            {
                continue;
            }

            int slot = slotChoice - 1;

            if (schedule[day][slot] >= MAX_APPOINTMENTS_PER_SLOT)
            {
                cout << "All workshop bays are occupied.\n";
                pauseScreen();
                continue;
            }

            cout << "\n0. Back\n";

            for (int i = 0; i < MECHANIC_COUNT; i++)
            {
                cout << i + 1 << ". " << MECHANICS[i] << " - ";

                if (mechanicFree(
                        appointments,
                        day,
                        slot,
                        MECHANICS[i]))
                {
                    cout << "Available\n";
                }
                else
                {
                    cout << "Not available\n";
                }
            }

            int mechanicChoice = numberInput(
                "Choose mechanic: ", 0, MECHANIC_COUNT);

            if (mechanicChoice == 0)
            {
                continue;
            }

            string mechanic = MECHANICS[mechanicChoice - 1];

            if (!mechanicFree(appointments, day, slot, mechanic))
            {
                cout << "Mechanic is not available.\n";
                pauseScreen();
                continue;
            }

            Appointment appointment;

            appointment.id = "A" + to_string(nextAppointment++);
            appointment.bookingId = bookings[bookingIndex].id;
            appointment.customerName = bookings[bookingIndex].customerName;
            appointment.plate = bookings[bookingIndex].plate;
            appointment.service = bookings[bookingIndex].service;
            appointment.mechanic = mechanic;
            appointment.status = "Scheduled";
            appointment.day = day;
            appointment.slot = slot;

            appointments.push_back(appointment);

            bookings[bookingIndex].status = "Scheduled";
            schedule[day][slot]++;

            saveAppointments(appointments);

            cout << "Appointment " << appointment.id
                 << " created successfully.\n";
        }

        else if (choice == 2)
        {
            for (int i = 0; i < WORKING_DAYS; i++)
            {
                cout << i + 1 << ". " << DATES[i] << '\n';
            }

            int dateChoice = numberInput(
                "Choose date (0 back): ", 0, WORKING_DAYS);

            if (dateChoice == 0)
            {
                continue;
            }

            int day = dateChoice - 1;

            cout << "\nDAILY SCHEDULE - " << DATES[day] << '\n';
            line(110);

            cout << left
                 << setw(21) << "Time Slot"
                 << setw(12) << "Appt ID"
                 << setw(12) << "Booking"
                 << setw(20) << "Customer"
                 << setw(13) << "Plate"
                 << setw(18) << "Mechanic"
                 << "Status\n";

            line(110);

            for (int slot = 0; slot < TIME_SLOT_COUNT; slot++)
            {
                bool found = false;

                for (int i = 0;
                     i < static_cast<int>(appointments.size());
                     i++)
                {
                    if (appointments[i].day == day &&
                        appointments[i].slot == slot &&
                        appointments[i].status != "Cancelled")
                    {
                        cout << left
                             << setw(21)
                             << (found ? "" : SLOTS[slot])
                             << setw(12) << appointments[i].id
                             << setw(12) << appointments[i].bookingId
                             << setw(20) << appointments[i].customerName
                             << setw(13) << appointments[i].plate
                             << setw(18) << appointments[i].mechanic
                             << appointments[i].status << '\n';

                        found = true;
                    }
                }

                if (!found)
                {
                    cout << left
                         << setw(21) << SLOTS[slot]
                         << setw(12) << "-"
                         << setw(12) << "-"
                         << setw(20) << "-"
                         << setw(13) << "-"
                         << setw(18) << "-"
                         << "Available\n";
                }
            }
        }

        else if (choice == 3 || choice == 4 || choice == 5)
        {
            if (appointments.empty())
            {
                cout << "No appointment record available.\n";
                cout << "Press Enter to return to Appointment Menu...";

                string input;
                getline(cin, input);

                continue;
            }

            cout << "\nAPPOINTMENT LIST\n";
            line(98);

            cout << left
                 << setw(5) << "No."
                 << setw(12) << "Appt ID"
                 << setw(12) << "Booking"
                 << setw(20) << "Customer"
                 << setw(25) << "Date"
                 << setw(18) << "Mechanic"
                 << "Status\n";

            line(98);

            vector<int> active;

            for (int i = 0; i < static_cast<int>(appointments.size()); i++)
            {
                if (appointments[i].status != "Cancelled")
                {
                    active.push_back(i);

                    const Appointment &appointment = appointments[i];

                    cout << left
                         << setw(5) << active.size()
                         << setw(12) << appointment.id
                         << setw(12) << appointment.bookingId
                         << setw(20) << appointment.customerName
                         << setw(25) << DATES[appointment.day]
                         << setw(18) << appointment.mechanic
                         << appointment.status << '\n';
                }
            }

            if (active.empty())
            {
                cout << "No active appointment available.\n";
                cout << "Press Enter to return to Appointment Menu...";

                string input;
                getline(cin, input);

                continue;
            }

            int selected = numberInput(
                "Choose appointment number (0 back): ",
                0,
                static_cast<int>(active.size()));

            if (selected == 0)
            {
                continue;
            }

            int index = active[selected - 1];

            if (choice == 3)
            {
                cout << "Rescheduling can be performed by cancelling "
                     << "and creating a new appointment.\n";
            }

            else if (choice == 4)
            {
                appointments[index].status = "Cancelled";

                schedule[appointments[index].day]
                        [appointments[index].slot]--;

                int bookingIndex = findBooking(
                    bookings,
                    appointments[index].bookingId);

                if (bookingIndex != -1)
                {
                    bookings[bookingIndex].status = "Pending";
                }

                saveAppointments(appointments);

                cout << "Appointment cancelled.\n";
            }

            else if (choice == 5)
            {
                cout << "1. Scheduled\n";
                cout << "2. In Service\n";
                cout << "3. Completed\n";

                int statusChoice = numberInput(
                    "New status (0 back): ", 0, 3);

                if (statusChoice == 0)
                {
                    continue;
                }

                const string status[] = {
                    "Scheduled", "In Service", "Completed"};

                appointments[index].status = status[statusChoice - 1];

                int bookingIndex = findBooking(
                    bookings,
                    appointments[index].bookingId);

                if (bookingIndex != -1)
                {
                    bookings[bookingIndex].status =
                        appointments[index].status;
                }

                saveAppointments(appointments);

                cout << "Status updated.\n";
            }
        }

        if (choice != 0)
        {
            pauseScreen();
        }

    } while (choice != 0);
}

// MODULE 4: BILLING, PAYMENT & REPORT
void displayDuitNowQR(const Invoice &invoice)
{
    cout << "\n========== DUITNOW QR PAYMENT (DEMO) ==========\n";
    cout << "## ## ## ## ## ## ## ## ## ## ## ##\n";
    cout << "##       ##  ####  ##  ##       ##\n";
    cout << "##  ##  ##  ##  ##  ####  ##  ##\n";
    cout << "##       ##  ####  ##  ##       ##\n";
    cout << "## ## ## ## ## ## ## ## ## ## ## ##\n";
    cout << "##  ##  ####  ##  ####  ##  ##  ##\n";
    cout << "####  ##  ####  ##  ##  ####  ####\n";
    cout << "##  ####  ##  ####  ##  ##  ######\n";
    cout << "## ## ## ## ## ## ## ## ## ## ## ##\n";
    cout << "Workshop : " << COMPANY_NAME << '\n';
    cout << "Invoice  : " << invoice.id << '\n';
    cout << "Amount   : RM " << fixed << setprecision(2)
         << invoice.total << '\n';
    cout << "===============================================\n";
}

void billingMenu(const vector<Customer> &customers,
                 vector<Invoice> &invoices,
                 int &nextInvoice)
{
    int choice;

    do
    {
        clearScreen();

        cout << "\n=== BILLING, PAYMENT & REPORT ===\n";
        cout << "1. Generate Invoice\n";
        cout << "2. Process Payment\n";
        cout << "3. Revenue Report\n";
        cout << "0. Return to Main Menu\n";

        choice = numberInput("Enter your choice: ", 0, 3);

        if (choice == 1)
        {
            if (customers.empty())
            {
                cout << "No customer record. Register a customer first.\n";
            }
            else
            {
                cout << "\nCUSTOMER LIST\n";
                line(80);

                cout << left
                     << setw(5) << "No."
                     << setw(12) << "Cust ID"
                     << setw(25) << "Customer"
                     << setw(16) << "Plate"
                     << "Vehicle\n";

                line(80);

                for (int i = 0; i < static_cast<int>(customers.size()); i++)
                {
                    cout << left
                         << setw(5) << i + 1
                         << setw(12) << customers[i].id
                         << setw(25) << customers[i].name
                         << setw(16) << customers[i].plate
                         << customers[i].brand << " "
                         << customers[i].model << '\n';
                }

                int selected = numberInput(
                    "Choose customer number (0 back): ",
                    0,
                    static_cast<int>(customers.size()));

                if (selected != 0)
                {
                    const Customer &customer = customers[selected - 1];

                    Invoice invoice;

                    invoice.id = "I" + to_string(nextInvoice++);
                    invoice.customerId = customer.id;
                    invoice.customerName = customer.name;
                    invoice.paymentMethod = "";
                    invoice.paymentStatus = "Pending";

                    cout << "\nInvoice ID: " << invoice.id << "\n";
                    cout << "Customer: " << customer.name
                         << " (" << customer.plate << ")\n";

                    double service = moneyInput("Service fee: ");
                    double labour = moneyInput("Labour charge: ");
                    double parts = moneyInput("Spare parts cost: ");

                    invoice.total = service + labour + parts;

                    invoices.push_back(invoice);

                    cout << "Invoice created. Total: RM "
                         << fixed << setprecision(2)
                         << invoice.total << '\n';
                }
            }
        }

        else if (choice == 2)
        {
            if (invoices.empty())
            {
                cout << "No invoice available. Generate an invoice first.\n";
            }
            else
            {
                cout << "\nINVOICE LIST\n";
                line(88);

                cout << left
                     << setw(5) << "No."
                     << setw(12) << "Invoice"
                     << setw(25) << "Customer"
                     << setw(15) << "Total (RM)"
                     << "Status\n";

                line(88);

                for (int i = 0; i < static_cast<int>(invoices.size()); i++)
                {
                    cout << left
                         << setw(5) << i + 1
                         << setw(12) << invoices[i].id
                         << setw(25) << invoices[i].customerName
                         << setw(15) << fixed << setprecision(2)
                         << invoices[i].total
                         << invoices[i].paymentStatus << '\n';
                }

                int selected = numberInput(
                    "Choose invoice number (0 back): ",
                    0,
                    static_cast<int>(invoices.size()));

                if (selected != 0)
                {
                    Invoice &invoice = invoices[selected - 1];

                    if (invoice.paymentStatus == "Paid")
                    {
                        cout << "This invoice has already been paid.\n";
                    }
                    else
                    {
                        const string paymentMethods[] = {
                            "Cash",
                            "Debit / Credit Card",
                            "DuitNow QR",
                            "Online Banking",
                            "E-Wallet"};

                        cout << "\nSELECT PAYMENT METHOD\n";
                        cout << "1. Cash\n";
                        cout << "2. Debit / Credit Card\n";
                        cout << "3. DuitNow QR\n";
                        cout << "4. Online Banking\n";
                        cout << "5. E-Wallet\n";
                        cout << "0. Back\n";

                        int method = numberInput(
                            "Choose payment method: ", 0, 5);

                        if (method != 0)
                        {
                            if (method == 3)
                            {
                                displayDuitNowQR(invoice);

                                string confirmation;

                                cout << "After payment is completed, "
                                     << "press Enter to confirm...";
                                getline(cin, confirmation);
                            }

                            invoice.paymentMethod =
                                paymentMethods[method - 1];

                            invoice.paymentStatus = "Paid";

                            cout << "Payment successful.\n";
                            cout << "Method: "
                                 << invoice.paymentMethod << "\n";
                            cout << "Amount paid: RM "
                                 << fixed << setprecision(2)
                                 << invoice.total << '\n';
                        }
                    }
                }
            }
        }

        else if (choice == 3)
        {
            double revenue = 0;
            int paid = 0;

            cout << "\nPAYMENT REPORT\n";
            line(88);

            cout << left
                 << setw(12) << "Invoice"
                 << setw(25) << "Customer"
                 << setw(22) << "Payment Method"
                 << setw(15) << "Total (RM)"
                 << "Status\n";

            line(88);

            for (int i = 0; i < static_cast<int>(invoices.size()); i++)
            {
                cout << left
                     << setw(12) << invoices[i].id
                     << setw(25) << invoices[i].customerName
                     << setw(22)
                     << (invoices[i].paymentMethod.empty()
                             ? "-"
                             : invoices[i].paymentMethod)
                     << setw(15) << fixed << setprecision(2)
                     << invoices[i].total
                     << invoices[i].paymentStatus << '\n';

                if (invoices[i].paymentStatus == "Paid")
                {
                    revenue += invoices[i].total;
                    paid++;
                }
            }

            if (invoices.empty())
            {
                cout << "No invoice records.\n";
            }

            cout << "\nPaid invoices: " << paid << "\n";
            cout << "Total revenue: RM "
                 << fixed << setprecision(2)
                 << revenue << '\n';
        }

        if (choice != 0)
        {
            pauseScreen();
        }

    } while (choice != 0);
}

int main()
{
    vector<Customer> customers;
    vector<Booking> bookings;
    vector<Appointment> appointments;
    vector<Invoice> invoices;

    int schedule[WORKING_DAYS][TIME_SLOT_COUNT] = {};

    int nextCustomer = 1001;
    int nextBooking = 1;
    int nextAppointment = 1;
    int nextInvoice = 1001;

    int choice;

    do
    {
        clearScreen();

        cout << "\n==================================================\n";
        cout << "             " << COMPANY_NAME << "\n";
        cout << "       CAR WORKSHOP MANAGEMENT SYSTEM\n";
        cout << "==================================================\n";
        cout << "1. Customer & Vehicle Management\n";
        cout << "2. Service Booking Management\n";
        cout << "3. Appointment / Schedule Management\n";
        cout << "4. Billing, Payment & Report\n";
        cout << "0. Exit\n";

        choice = numberInput("Enter your choice: ", 0, 4);

        switch (choice)
        {
        case 1:
            customerMenu(
                customers,
                bookings,
                appointments,
                nextCustomer);
            break;

        case 2:
            bookingMenu(
                customers,
                bookings,
                nextBooking);
            break;

        case 3:
            appointmentMenu(
                appointments,
                bookings,
                schedule,
                nextAppointment);
            break;

        case 4:
            billingMenu(
                customers,
                invoices,
                nextInvoice);
            break;

        case 0:
            cout << "Thank you for using the Car Workshop Management System.\n";
            break;
        }

    } while (choice != 0);

    return 0;
}